package com.example.ctpbusmanagement

data class Vehicle (
    val picture: String,
    val lineNumber: String,
    val startStation: String,
    val stopStation: String,
    val vehicleType: String
        )